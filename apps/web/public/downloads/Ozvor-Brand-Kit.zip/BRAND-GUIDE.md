# Ozvor — Brand Kit

_Ozvor · AI Search Trust Intelligence · ozvor.com_

Use these assets across every channel. The system is **dark-first, confident, and
technical-but-human**. Protected names that never change: **"Ozvor AI Visibility Score"**
(the 3-vector score) and **"OrganicPosts by Ozvor"** (the done-with-you arm).

---

## 1. Logo — the O-ring

The mark is a **monochrome O-ring**: a dashed orbit (the "scan" of AI engines
circling your brand) with a solid centre dot (your brand at the centre). It is
always one colour (`currentColor`) — emerald on dark, ink on light. Never a tile,
never multicolour, never the old bar-chart mark.

- **Primary:** emerald O-ring on the dark canvas.
- **Wordmark:** "Ozvor", weight 800, tight tracking (-0.02em). Title-case, never all-caps in the logo.
- **Clear space:** keep at least the ring's radius clear on all sides.
- **Min size:** ring 20px; full lockup 96px wide.
- **Don'ts:** don't recolour the ring per-segment, add shadows/gradients to the mark, rotate it, stretch it, or place the emerald ring on a busy photo (use the ink/white ring instead).

---

## 2. Colour

| Token | Hex | Use |
|---|---|---|
| Canvas (dark) | `#0a0f0d` | Default background |
| Emerald | `#27c98a` | Primary accent, the ring, self-serve CTAs |
| Emerald deep | `#0c7d54` | Gradient end, links on light |
| Accent ink | `#5fdfa8` | Emerald text on dark |
| Gold | `#e6a93f` | **Reserved for OrganicPosts** (done-with-you) + the emerald→gold ladder hairline |
| Ink (text) | `#f4f7f5` | Text on dark |
| Muted | `#9fb0a4` | Secondary text on dark |
| Cream (print) | `#f6f3ea` | PDF / light surfaces |

**Accent rule:** emerald = self-serve (Free / Kit / Growth / Agency). **Gold is reserved for OrganicPosts only.** Don't use gold as a generic accent.

---

## 3. Type

- **Display & UI:** Schibsted Grotesk (weights 400–800). Fallback: Helvetica Neue / Arial.
- **Mono / code / data:** JetBrains Mono.
- Headlines are tight (-0.02 to -0.03em), bold (700–800), sentence case.

---

## 4. Voice

Plain, specific, honest. We sell clarity, not hype. We never *guarantee* AI
citations (the systems are non-deterministic) — we measure and improve the
probability. Lead with the customer's problem ("when a buyer asks AI, does it
name you?"), back claims with named sources, and keep a calm, expert tone.

Tagline: **"Know if AI trusts your brand."** (extended: "…Then fix it.")

---

## 5. What's in this kit

All files are in `/assets`. See `CHANNELS.md` for exact placement and dimensions.

- **Avatars (square, 1024×1024):** `avatar-ozvor` (emerald ring + wordmark), `avatar-icon` (emerald ring only — best at small sizes), `avatar-white` + `avatar-icon-white` (**white / mono — exactly as the logo appears in the site nav & footer**), `avatar-emerald` (for light surfaces).
- **Standalone logo files (`/assets/logo`, transparent PNG):** `logo-mark-*` (ring only) and `logo-lockup-*` (ring + wordmark) in **white** (on dark — matches the site), **ink** (`#14201a`, on light), and **emerald** (accent). Drop these over photos, video, slides, or print.
- **Banners/headers:** LinkedIn (company + personal), X/Twitter, Reddit, Facebook, YouTube.
- **Post templates:** Instagram square + story, generic OG/share.

PNG, transparent-free (solid dark canvas), exported at platform-native sizes.
Need a different size? Re-run `node scripts/gen-brand-kit.mjs` — every asset is
generated from code, so the kit stays perfectly on-brand.
