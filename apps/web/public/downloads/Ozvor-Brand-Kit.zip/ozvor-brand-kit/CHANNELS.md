# Ozvor — Channel Placement Guide

Exact file → where it goes → native dimensions. (Platforms tweak specs over time;
these are correct as of 2026. The square avatar scales down cleanly everywhere.)

## Avatars (profile pictures)
| File | Size | Use on |
|---|---|---|
| `assets/avatar-icon-1024.png` | 1024×1024 | **Best for small avatars** — Reddit, X, Instagram, favicons. The ring reads at tiny sizes. |
| `assets/avatar-ozvor-1024.png` | 1024×1024 | LinkedIn company logo, YouTube channel icon, Facebook page — where the avatar renders larger. |
| `assets/avatar-white-1024.png` · `assets/avatar-icon-white-1024.png` | 1024×1024 | **White / mono** — the logo as it appears on the site. Use anywhere you want the restrained, monochrome look. |
| `assets/avatar-emerald-1024.png` | 1024×1024 | Any context with a light/white surrounding UI. |
| `assets/logo/logo-{mark,lockup}-{white,ink,emerald}.png` | transparent | Standalone logo to overlay on photos/video/slides/print. White on dark, ink on light, emerald as accent. |

## Banners & headers
| File | Size | Platform |
|---|---|---|
| `assets/linkedin-company-cover-1128x191.png` | 1128×191 | LinkedIn **company page** cover |
| `assets/linkedin-personal-banner-1584x396.png` | 1584×396 | LinkedIn **personal profile** background |
| `assets/x-header-1500x500.png` | 1500×500 | X / Twitter header |
| `assets/reddit-banner-1920x384.png` | 1920×384 | Reddit profile / community banner |
| `assets/facebook-cover-1200x630.png` | 1200×630 | Facebook page cover |
| `assets/youtube-banner-2560x1440.png` | 2560×1440 | YouTube channel art (logo/text sit inside the 1546×423 safe area, visible on every device) |

## Posts & sharing
| File | Size | Use |
|---|---|---|
| `assets/instagram-post-1080x1080.png` | 1080×1080 | Instagram / LinkedIn / Facebook square post (announcement, intro) |
| `assets/instagram-story-1080x1920.png` | 1080×1920 | Instagram / TikTok / WhatsApp story |
| `assets/og-share-1200x630.png` | 1200×630 | Generic link-share / Open Graph (same look as the site's og-default) |

## Handles
Claim a consistent handle everywhere: **@ozvor** (or `ozvor` / `getozvor` where taken).
Bio line: *"AI Search Trust Intelligence for SMBs. Know if AI trusts your brand — then fix it. ozvor.com"*
